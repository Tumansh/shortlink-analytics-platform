package com.tumansh.shortlink;

public class AnalyticsIntegrationTest {
}
