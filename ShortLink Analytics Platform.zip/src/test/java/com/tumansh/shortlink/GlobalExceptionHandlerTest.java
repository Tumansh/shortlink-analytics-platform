package com.tumansh.shortlink;

public class GlobalExceptionHandlerTest {
}
