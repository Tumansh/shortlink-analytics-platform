package com.tumansh.shortlink;

public class RedisIntegrationTest {
}
