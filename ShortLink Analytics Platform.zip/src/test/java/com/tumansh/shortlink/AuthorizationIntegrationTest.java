package com.tumansh.shortlink;

public class AuthorizationIntegrationTest {
}
