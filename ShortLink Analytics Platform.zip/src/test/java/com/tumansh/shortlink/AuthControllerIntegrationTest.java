package com.tumansh.shortlink;

public class AuthControllerIntegrationTest {
}
