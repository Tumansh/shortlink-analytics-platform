package com.tumansh.shortlink;

public class ShortUrlControllerIntegrationTest {
}
