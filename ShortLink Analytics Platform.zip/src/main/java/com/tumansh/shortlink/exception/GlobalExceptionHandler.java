package com.tumansh.shortlink.exception;

import com.tumansh.shortlink.dto.response.ApiResponse;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(
            EmailAlreadyExistsException.class
    )
    @ResponseStatus(HttpStatus.CONFLICT)
    public ApiResponse handleEmailExists(
            EmailAlreadyExistsException ex) {

        return new ApiResponse(
                ex.getMessage()
        );
    }

    @ExceptionHandler(
            InvalidCredentialsException.class
    )
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public ApiResponse handleUserCredentials(
            InvalidCredentialsException ex) {

        return new ApiResponse(
                ex.getMessage()
        );
    }

    @ExceptionHandler(
            ShortUrlNotFoundException.class
    )
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ApiResponse handleShortUrlNotFound(
            ShortUrlNotFoundException ex) {

        return new ApiResponse(
                ex.getMessage()
        );
    }

    @ExceptionHandler(
            AccessDeniedException.class
    )
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public ApiResponse handleAccessDenied(
            AccessDeniedException ex) {

        return new ApiResponse(
                ex.getMessage()
        );
    }

    @ExceptionHandler(
            UserNotFoundException.class
    )
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ApiResponse handleUserNotFound(
            UserNotFoundException ex) {

        return new ApiResponse(
                ex.getMessage()
        );
    }

}


