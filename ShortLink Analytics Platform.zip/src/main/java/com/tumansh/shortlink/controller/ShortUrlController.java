package com.tumansh.shortlink.controller;

import com.tumansh.shortlink.dto.request.CreateShortUrlRequest;
import com.tumansh.shortlink.dto.response.*;
import com.tumansh.shortlink.service.ShortUrlService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/urls")
public class ShortUrlController {

    private final ShortUrlService shortUrlService;

    public ShortUrlController(ShortUrlService shortUrlService) {

        this.shortUrlService = shortUrlService;
    }

    @PostMapping
    public ShortUrlResponse createShortUrl(@Valid @RequestBody CreateShortUrlRequest request) {

        return shortUrlService.createShortUrl(request);
    }

    @GetMapping("/redirect/{shortCode}")
    public ResponseEntity<Void> redirect(@PathVariable String shortCode, HttpServletRequest request) {

        String ipAddress = request.getRemoteAddr();
        String userAgent = request.getHeader("User-Agent");

        String originalUrl = shortUrlService.getOriginalUrl(shortCode, ipAddress, userAgent);

        HttpHeaders headers = new HttpHeaders();
        headers.setLocation(URI.create(originalUrl));

        return ResponseEntity.status(HttpStatus.FOUND).headers(headers).build();
    }

    //    @PreAuthorize("hasRole('ADMIN')")
    //    @GetMapping
    //    public List<UrlDetailsResponse> getAllUrls() {
    //        return shortUrlService.getAllUrls();
    //    }
    @GetMapping("/my")
    public List<MyUrlsResponse> getMyUrls() {
        return shortUrlService.getMyUrls();
    }

    @GetMapping("/{shortCode}")
    public UrlDetailsResponse getUrl(@PathVariable String shortCode) {

        return shortUrlService.getUrl(shortCode);
    }

    @DeleteMapping("/{shortCode}")
    public ApiResponse deleteUrl(@PathVariable String shortCode) {

        shortUrlService.deleteUrl(shortCode);

        return new ApiResponse("Short URL deleted successfully");
    }

    @GetMapping("/analytics/{shortCode}")
    public AnalyticsResponse getAnalytics(@PathVariable String shortCode) {

        return shortUrlService.getAnalytics(shortCode);
    }
}